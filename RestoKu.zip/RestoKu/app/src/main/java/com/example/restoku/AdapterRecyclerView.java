package com.example.restoku;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class AdapterRecyclerView extends RecyclerView.Adapter<AdapterRecyclerView.ViewHolder> {

    private ArrayList<ItemModel> dataItem;
    private Context context;


    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView textHead;
        TextView textSubhead;
        ImageView imageIcon;
        LinearLayoutCompat constraintLayout;

        public ViewHolder(@NonNull View itemView){
            super(itemView);

            textHead=itemView.findViewById(R.id.textProduk);
            textSubhead= itemView.findViewById(R.id.textHarga);
            imageIcon = itemView.findViewById(R.id.fotoProduk);
            constraintLayout = itemView.findViewById(R.id.constraintLayout);


        }
    }

    AdapterRecyclerView(Context context,ArrayList<ItemModel> dataItem){
        this.context = context;
        this.dataItem = dataItem;

    }

    @NonNull
    @Override
    public AdapterRecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterRecyclerView.ViewHolder holder, int position) {
        TextView textHead = holder.textHead;
        TextView textSubhead = holder.textSubhead;
        ImageView imageIcon = holder.imageIcon;

        textHead.setText(dataItem.get(position).getName());
        textSubhead.setText(dataItem.get(position).getType());
        imageIcon.setImageResource(dataItem.get(position).getImage());

        holder.constraintLayout.setOnClickListener(v ->{
            Toast.makeText(context, dataItem.get(position).getName(),Toast.LENGTH_SHORT).show();

            if (dataItem.get(position).getName().equals("Pecel Lele")){
                context.startActivity(new Intent(context,DetailActivity.class));
            }
            if (dataItem.get(position).getName().equals("Nasi Goreng")){
                context.startActivity(new Intent(context,Nasgor.class));
            }
            if (dataItem.get(position).getName().equals("Indomi kuah/goreng")){
                context.startActivity(new Intent(context,Indomie.class));
            }
            if (dataItem.get(position).getName().equals("Nasi Ayam Geprek")){
                context.startActivity(new Intent(context,Geprek.class));
            }
            if (dataItem.get(position).getName().equals("Mendoan Purwokerto")){
                context.startActivity(new Intent(context,Mendoan.class));
            }
            if (dataItem.get(position).getName().equals("Rujak Buwah")){
                context.startActivity(new Intent(context,Rujak.class));
            }




        } );
    }

    @Override
    public int getItemCount() {
        return dataItem.size();
    }


    }

