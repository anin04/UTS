package com.example.restoku;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Indomie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_indomie);
    }
}