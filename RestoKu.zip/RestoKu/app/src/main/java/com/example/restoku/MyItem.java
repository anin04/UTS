package com.example.restoku;

public class MyItem {

    static int[] iconList = {
            R.drawable.pecel, R.drawable.nasgor,R.drawable.mi,R.drawable.geprek,
            R.drawable.tempe,R.drawable.rujak
    };

    static String[] Headline= {
            "Pecel Lele","Nasi Goreng","Indomi kuah/goreng", "Nasi Ayam Geprek","Mendoan Purwokerto",
            "Rujak Buwah"
    };
    static String[] Subheadline = {
           "Rp. 15.000","Rp. 14.000","Rp. 8.000","Rp. 15.000",
            "Rp. 10.000", "Rp. 7.000"
    };
}
